-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 16, 2022 at 10:25 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leave_staff`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', '2022-03-26 17:52:32');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL,
  `DepartmentName` varchar(150) DEFAULT NULL,
  `DepartmentShortName` varchar(100) NOT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`id`, `DepartmentName`, `DepartmentShortName`, `CreationDate`) VALUES
(2, 'COMPUTER SCIENCE ENGINEERING', 'CSE', '2017-11-01 07:19:37'),
(3, 'MECHANICAL ENGINEERING', 'MECH', '2021-05-21 08:27:45'),
(4, 'ELECTRONICS AND COMMUNICATIONS ENGINEERING', 'ECE', '2022-03-27 16:48:09'),
(5, 'ELECTRICAL AND ELECTRONICS ENGINEERING', 'EEE', '2022-05-16 17:57:11');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `emp_id` int(11) NOT NULL,
  `FirstName` varchar(150) NOT NULL,
  `LastName` varchar(150) NOT NULL,
  `EmailId` varchar(200) NOT NULL,
  `Password` varchar(180) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Dob` varchar(100) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `Av_leave` varchar(150) NOT NULL,
  `Phonenumber` char(11) NOT NULL,
  `Status` int(1) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` varchar(30) NOT NULL,
  `location` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`emp_id`, `FirstName`, `LastName`, `EmailId`, `Password`, `Gender`, `Dob`, `Department`, `Address`, `Av_leave`, `Phonenumber`, `Status`, `RegDate`, `role`, `location`) VALUES
(1, 'MR', 'ARUN KUAMR', 'arun@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'Male', '3 February, 1990', 'CSE', 'Amritanagar, Ettimadai', '30', '9134567765', 1, '2017-11-10 11:29:59', 'HOD', 'p1.jpg'),
(6, 'MR', 'SABARISH', 'sabarish@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'Male', '3 February, 1990', 'CSE', 'Amritanagar, Ettimadai', '30', '6790345654', 1, '2017-11-10 13:40:02', 'Staff', 'p3.jpg'),
(8, 'MR', 'SENTHIL KUMAR', 'senthil@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'Male', '3 February, 1990', 'CSE', 'Amritanagar, Ettimadai', '30', '8903454589', 1, '2017-11-10 13:40:02', 'Staff', 'p5.jpg'),
(9, 'MRS', 'SUJEE', 'sujee@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'female', '01 May 1980', 'CSE', 'Amritanagar, Ettimadai', '30', '7723445636', 1, '2022-03-27 16:54:10', 'Staff', 'p4.jpg'),
(10, 'MR', 'VENKATARAMAN', 'venkat@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'male', '10 May 1990', 'CSE', 'Amritanagar, Ettimadai', '30', '8900987651', 1, '2022-03-27 18:06:26', 'HOD', 'p2.jpg'),
(11, 'MR', 'ANBAZHAGAN', 'anbazhagan@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'male', '20 July 1999', 'CSE', 'Amritanagar, Ettimadai', '30', '7708543294', 1, '2022-05-16 18:00:29', 'Admin', 'p6.jpeg'),
(12, 'MRS', 'PRIYANKA', 'priya@gmail.com', '21232f297a57a5a743894a0e4a801fc3', 'female', '07 May 1980', 'CSE', 'Amritanagar, Ettimadai', '30', '9491624117', 1, '2022-05-16 18:55:15', 'Admin', 'p7.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblleaves`
--

CREATE TABLE `tblleaves` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(110) NOT NULL,
  `ToDate` varchar(120) NOT NULL,
  `FromDate` varchar(120) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` date NOT NULL,
  `AdminRemark` mediumtext DEFAULT NULL,
  `registra_remarks` mediumtext NOT NULL,
  `AdminRemarkDate` varchar(120) DEFAULT NULL,
  `Status` int(1) NOT NULL,
  `admin_status` int(11) NOT NULL DEFAULT 0,
  `IsRead` int(1) NOT NULL,
  `empid` int(11) DEFAULT NULL,
  `num_days` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleaves`
--

INSERT INTO `tblleaves` (`id`, `LeaveType`, `ToDate`, `FromDate`, `Description`, `PostingDate`, `AdminRemark`, `registra_remarks`, `AdminRemarkDate`, `Status`, `admin_status`, `IsRead`, `empid`, `num_days`) VALUES
(13, 'Casual Leave', '2021-05-02', '2021-05-12', 'I want to take a leave.', '2021-05-20', 'Ok', 'ok', '2021-05-24 20:26:19 ', 1, 1, 1, 7, 3),
(14, 'Medical Leave', '08-05-2021', '11-05-2021', 'Noted', '0000-00-00', 'Not Accepted', 'Leave was Rejected. Registra/Registry will not see it', '2022-05-17 0:46:35 ', 2, 2, 1, 6, 4),
(16, 'On Duty ', '02-05-2021', '05-05-2021', 'Event Leave', '2021-05-20', 'Ok', 'Noted', '2021-05-24 20:42:18 ', 1, 1, 1, 7, 4),
(17, 'Casual Leave', '11-05-2021', '15-05-2021', 'Just', '2021-05-21', 'Leave Approved', 'Noted', '2021-05-24 19:56:45 ', 1, 1, 1, 7, 5),
(18, 'On Duty ', '28-03-2022', '28-03-2022', 'Outing', '2022-03-27', NULL, '', NULL, 0, 0, 0, 1, 1),
(19, 'Emergency Leave', '28-03-2022', '29-03-2022', 'Plz approve fast', '2022-03-27', 'ok', 'Its ok', '2022-03-27 22:59:55 ', 1, 1, 1, 8, 2),
(20, 'Medical Leave', '10-03-2022', '11-03-2022', 'Leg pain', '2022-03-27', NULL, '', NULL, 0, 0, 1, 9, 2),
(21, 'Casual Leave', '18-05-2022', '19-05-2022', 'General Leave', '2022-05-16', 'Done', 'Not Accepted', '2022-05-17 1:10:51 ', 1, 2, 1, 8, 2),
(22, 'Medical Leave', '20-05-2022', '25-05-2022', 'Visiting Hospital', '2022-05-16', 'Done\r\n', '', '2022-05-17 1:08:11 ', 1, 0, 1, 6, 6),
(23, 'On Duty ', '18-05-2022', '21-05-2022', 'On Duty', '2022-05-16', 'Rejected', 'Leave was Rejected. Registra/Registry will not see it', '2022-05-17 1:15:17 ', 2, 2, 1, 9, 4),
(24, 'Medical Leave', '18-05-2022', '21-05-2022', 'Medical', '2022-05-16', NULL, '', NULL, 0, 0, 0, 10, 4),
(25, 'Casual Leave', '18-05-2022', '20-05-2022', 'Casual', '2022-05-16', NULL, '', NULL, 0, 0, 0, 1, 3),
(26, 'Casual Leave', '20-05-2022', '21-05-2022', 'casual', '2022-05-16', NULL, '', NULL, 0, 0, 0, 10, 2);

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `date_from` varchar(200) NOT NULL,
  `date_to` varchar(200) NOT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`id`, `LeaveType`, `Description`, `date_from`, `date_to`, `CreationDate`) VALUES
(5, 'Casual Leave', 'Casual Leave', '2021-05-23', '2021-06-20', '2021-05-19 14:32:03'),
(6, 'Medical Leave', 'Medical Leave', '2021-05-05', '2021-05-28', '2021-05-19 15:29:05'),
(8, 'On Duty ', 'Leave all staff', '31-05-2021', '04-06-2021', '2021-05-20 17:17:43'),
(9, 'Emergency Leave', 'Emergency Leave', '27-03-2022', '27-10-2023', '2022-03-27 16:50:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`emp_id`);

--
-- Indexes for table `tblleaves`
--
ALTER TABLE `tblleaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserEmail` (`empid`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `emp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tblleaves`
--
ALTER TABLE `tblleaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
